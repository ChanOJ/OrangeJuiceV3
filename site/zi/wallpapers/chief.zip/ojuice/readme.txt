orange juice wallpaper
by chief/asylum (chief_asylum@yahoo.co.uk)

2 versions - 800x600 res.
           & 1024x768 res (4 people with big screens)

i recommend using transp32(included in zip)
this util removes ugly background of icon text!