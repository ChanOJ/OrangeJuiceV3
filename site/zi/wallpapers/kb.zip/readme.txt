
  _   _  _____ ___  ___ ______  _____  __  __  _____  __  _____  _____
 |  \| ||  ___|\  \/  /|_    _||  ___||  \/  ||   __\|  ||  ___\|  ___|
 |     ||  ___| >    <   |  |  |  ___||      ||   __/|  ||     /|  ___|
 |_|\__||_____|/__/\__\  |__|  |_____||_|\/|_||__|   |__||__|\_\|_____|
                                                     www.nextempire.com


 .an orangejuice wallpaper
 .called
 .would you like some...
 
 .resolution 1280*1024
 .others on request 



 .simple, clean, stylish
 .hope you like it
 .I do

 .KOWBOY/NEXTEMPIRE
